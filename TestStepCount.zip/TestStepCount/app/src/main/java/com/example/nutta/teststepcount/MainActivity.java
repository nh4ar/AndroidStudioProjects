package com.example.nutta.teststepcount;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.support.wearable.activity.WearableActivity;
import android.widget.TextView;

public class MainActivity extends WearableActivity {

    private TextView mTextView;

    private SensorManager sensorManager;
    private Sensor sensor;

    private float steps=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTextView = (TextView) findViewById(R.id.text);

        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        sensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER);

//        sensorManager.registerListener(stepCountListener, sensor, SensorManager.SENSOR_DELAY_FASTEST);

        // Enables Always-on
        setAmbientEnabled();
    }

    protected void onResume(){
        super.onResume();
        sensorManager.registerListener(stepCountListener, sensor, SensorManager.SENSOR_DELAY_NORMAL);
    }

    protected void onPause(){
        super.onPause();
        sensorManager.unregisterListener(stepCountListener);
    }

    private SensorEventListener stepCountListener = new SensorEventListener() {
        private float mStepOffset;

        @Override
        public void onSensorChanged(SensorEvent event) {
            if (mStepOffset == 0) {
                mStepOffset = event.values[0];
            }
            mTextView.setText(Float.toString(event.values[0] - mStepOffset));
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {

        }
    };
}
