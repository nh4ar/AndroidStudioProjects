package com.example.nutta.testtimestamp;

import android.os.Bundle;
import android.support.wearable.activity.WearableActivity;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Calendar;
import java.util.TimeZone;

public class MainActivity extends WearableActivity {

    private TextView mTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mTextView = (TextView) findViewById(R.id.text);
        final Button mButton = findViewById(R.id.button);
        mButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mTextView.setText(String.valueOf(getEpochTime()));
            }
        });

        // Enables Always-on
        setAmbientEnabled();
    }

    public long getEpochTime(){
        return Calendar.getInstance(TimeZone.getTimeZone("GMT+4")).getTime().getTime(); //(  milliseconds )
    }


}
